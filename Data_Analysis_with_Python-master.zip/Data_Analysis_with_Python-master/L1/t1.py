# 输入与输出
name = input("What's your name?")
sum = 100+100
print ('hello,%s' %name)
print ('sum = %d' %sum)
