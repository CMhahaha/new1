# for循环
sum = 0
for number in range(11):
    sum = sum + number
print(sum)


# while循环
sum = 0
number = 1
while number < 11:
       sum = sum + number
       number = number + 1
print(sum)